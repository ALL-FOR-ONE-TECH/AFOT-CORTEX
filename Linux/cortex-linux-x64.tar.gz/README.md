# 🧠 AFOT CORTEX

**AI Framework for Offensive Tools** - Sandbox-Embedded LLM with Tool Binding

[![Rust](https://img.shields.io/badge/rust-1.70%2B-orange.svg)](https://www.rust-lang.org/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Status](https://img.shields.io/badge/status-production--ready-brightgreen.svg)]()

> **Turn any command-line tool into an AI-powered agent. Chat with LLMs that can execute your tools safely.**

---

## ✨ What is AFOT CORTEX?

**CORTEX** is a production-ready framework that combines **Local LLMs** (Ollama) with **tool execution** in a **secure sandbox**.

**You Chat** → **LLM Generates Code** → **Sandbox Executes** → **Results Displayed**

### Key Features

- 🔐 **Manifest-Controlled Security** - Define what tools can access
- 🤖 **LLM Intelligence** - Uses Ollama (llama3.2, llama3, etc.)
- 📦 **Sandboxed Execution** - Python, JavaScript, Shell support
- 🛠️ **Tool Binding** - Bind ANY command-line tool
- 💬 **Conversational** - Natural language → Tool execution
- 🔍 **Network Security** - Nmap integration via WSL Kali

---

## 🚀 Quick Start

### 1. Prerequisites
```bash
# Install Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Install Ollama
curl https://ollama.ai/install.sh | sh

# Pull LLM model
ollama pull llama3.2:3b

# (Optional) Install WSL Kali for nmap
wsl --install
wsl -d kali-linux sudo apt install nmap
```

### 2. Build CORTEX
```bash
git clone https://github.com/karthikeyanV2K/afot-cortex
cd afot-cortex
cargo build --release --bin cortex
```

### 3. Try the Demo
```bash
cd Demo
cortex bind capabilities.yaml
cortex list
cortex chat

You: Scan scanme.nmap.org with nmap
You: Create folder C:/temp/test
```

---

## 📋 All Commands

```bash
cortex bind <manifest>    # Bind tools from manifest
cortex unbind              # Remove current binding
cortex list                # Show bound tools and status
cortex chat                # Interactive LLM session
cortex test <manifest>     # Validate manifest file
cortex create -n <name>    # Generate new agent template
cortex --help              # Show help
```

---

## 🎯 How It Works

### Architecture

```
┌─────────────┐
│  User Chat  │  "Scan target.com with nmap"
└──────┬──────┘
       ↓
┌─────────────┐
│  LLM (Ollama) │  Generates Python subprocess code
└──────┬──────┘
       ↓
┌─────────────┐
│ Interceptor │  Detects code block
└──────┬──────┘
       ↓
┌─────────────┐
│   Manifest  │  Validates permissions
└──────┬──────┘
       ↓
┌─────────────┐
│   Sandbox   │  Executes safely
└──────┬──────┘
       ↓
┌─────────────┐
│ WSL/Python  │  Runs actual tool
└──────┬──────┘
       ↓
   Results
```

### Workflow

1. **Bind Manifest** - Load tools once (`cortex bind`)
2. **Check Status** - See bound tools (`cortex list`)
3. **Start Chat** - Interactive session (`cortex chat`)  
4. **Natural Language** - Ask LLM to use tools
5. **Code Generation** - LLM generates execution code
6. **User Confirms** - Review and approve
7. **Sandbox Executes** - Runs in isolated environment
8. **View Results** - See output immediately

---

## � Creating Your Own Tools

### Step 1: Write Your Tool

#### Python Tool
```python
# my_tool.py
import sys

def main():
    target = sys.argv[1] if len(sys.argv) > 1 else "localhost"
    print(f"Scanning {target}...")
    # Your logic here
    return {"status": "success", "target": target}

if __name__ == "__main__":
    main()
```

#### Shell Tool
```bash
# scan.sh
#!/bin/bash
nmap -sV "$1"
```

### Step 2: Create Manifest

```yaml
name: "my_agent"
version: "1.0.0"
base_model: "llama3.2:3b"

bindings:
  - name: "scan_tool"
    language: "python"
    entrypoint: "my_tool.py"
    description: "Custom scanning tool"
    input_schema:
      type: "object"
      properties:
        target:
          type: "string"
          description: "Target to scan"
      required: ["target"]
    output_schema:
      type: "object"
      properties:
        status:
          type: "string"

capabilities:
  file_system_write:
    enabled: true
    allowed_paths:
      - "C:/temp/*"
      - "C:/data/*"
    require_confirmation: true
  
  network_access:
    enabled: true
    unrestricted: false
    allowed_domains:
      - "*.example.com"
      - "scanme.nmap.org"
    require_confirmation: true
    max_timeout: 300

description: "My custom security agent"
```

### Step 3: Bind and Use

```bash
cortex bind my_manifest.yaml
cortex chat

You: Scan example.com
→ LLM generates code calling my_tool.py
→ Sandbox executes
→ Results displayed!
```

---

## � Security Features

### Manifest-Controlled Permissions

```yaml
capabilities:
  file_system_write:
    enabled: true
    allowed_paths: ["C:/temp/*"]  # Whitelist
    blocked_paths: ["C:/Windows"]  # Blacklist
    require_confirmation: true     # User approval
  
  network_access:
    enabled: true
    unrestricted: false             # Restrict by domain
    allowed_domains: ["*.safe.com"]
    max_timeout: 600                # 10 min max
```

### Safety Layers

1. **Manifest Validation** - Tools must be explicitly allowed
2. **Path Restrictions** - File access controlled by manifest
3. **User Confirmation** - Approve each code execution
4. **Sandbox Isolation** - Code runs in isolated environment
5. **Timeout Protection** - Max execution time enforced

---

## 💡 Example Use Cases

### Network Reconnaissance
```
You: Scan my network 192.168.1.0/24
→ LLM: Generates nmap scan
→ Execute: wsl nmap -sn 192.168.1.0/24
→ Results: List of live hosts
```

### Vulnerability Assessment
```
You: Check scanme.nmap.org for vulnerabilities
→ LLM: nmap --script vuln
→ Results: Vulnerability report
```

### Workflow Automation
```
You: Scan target, then create folder with results
→ LLM: Multi-step code generation
1. Run nmap scan
2. Create results folder
3. Save output
```

---

## � Project Structure

```
afot-cortex/
├── afot-cortex/              # Core library
│   ├── src/
│   │   ├── binding/          # Manifest system
│   │   ├── sandbox/          # Execution engine
│   │   ├── interceptor/      # Code detection
│   │   └── llm/              # Ollama client
│   └── Cargo.toml
│
├── afot-cortex-cli/          # CLI tool
│   ├── src/
│   │   └── main.rs          # Commands implementation
│   └── Cargo.toml
│
├── Demo/                     # Working example
│   ├── capabilities.yaml    # Network tools manifest
│   ├── nmap.py              # Nmap wrapper
│   └── README.md            # Demo guide
│
├── README.md                 # This file
└── Cargo.toml                # Workspace config
```

---

## �️ Advanced Features

### Conversation Memory

CORTEX remembers last 5 exchanges:

```
You: Scan afot.in
→ Basic scan performed

You: Now do service detection
→ Remembers target, adds -sV flag

You: Check for web vulnerabilities
→ Adds --script http-vuln-*
```

### Multi-Language Support

- **Python** - `/usr/bin/python3`
- **JavaScript** - Node.js via `node`
- **Shell** - PowerShell → WSL for Linux tools

### Smart Code Generation

LLM is context-aware:
- **Chat queries** → Normal response, NO code
- **Action requests** → Generates code
- **Follow-ups** → Uses conversation history

```
You: hi                          → Chat response
You: What is nmap?               → Explanation
You: Scan localhost              → Generates code ✅
```

---

## 🧪 Testing

### Run Tests
```bash
# Validate manifest
cortex test -m Demo/capabilities.yaml

# Build and test
cargo test --workspace

# Integration test
cd Demo
cortex bind capabilities.yaml
cortex list
```

---

## 🐛 Troubleshooting

### Ollama Not Found
```bash
# Check Ollama service
ollama list

# Start Ollama
ollama serve
```

### Nmap Command Not Found
```bash
# Install in WSL Kali
wsl -d kali-linux
sudo apt update && sudo apt install nmap
```

### Build Errors
```bash
# Clean and rebuild
cargo clean
cargo build --release --bin cortex
```

### Permission Denied
- Check `allowed_paths` in manifest
- Ensure user has write access to target directory

---

## 📖 Documentation

- **[Demo README](Demo/README.md)** - Complete usage guide
- **[Architecture](ARCHITECTURE_MIGRATION.md)** - System design
- **[Security](SECURITY.md)** - Security model
- **[Getting Started](GETTING_STARTED.md)** - Beginner guide

---

## 🗺️ Roadmap

- [x] Core sandbox execution
- [x] LLM integration (Ollama)
- [x] Tool binding framework
- [x] CLI interface
- [x] Conversation memory
- [x] Nmap integration
- [ ] Web UI dashboard
- [ ] More tool integrations (Metasploit, SQLMap)
- [ ] Cloud deployment support
- [ ] API server mode

---

## 🤝 Contributing

Contributions welcome!

```bash
1. Fork the repo
2. Create feature branch (git checkout -b feature/amazing-feature)
3. Commit changes (git commit -m 'Add amazing feature')
4. Push to branch (git push origin feature/amazing-feature)
5. Open Pull Request
```

---

## ⚖️ Legal Notice

**IMPORTANT**: Use CORTEX only on systems you own or have explicit written permission to test.

- Unauthorized network scanning is **illegal**
- Always obtain **written authorization**
- Review **audit logs** regularly
- Follow **responsible disclosure**

**The authors assume NO liability for misuse.**

---

## 📜 License

MIT License - See [LICENSE](LICENSE) for details

---

## 🙏 Credits

**Built With**:
- 🦀 **Rust** - Systems programming language
- 🤖 **Ollama** - Local LLM runtime
- 🐍 **Python** - Tool integration
- 🐧 **WSL Kali** - Linux tool support

**Special Thanks**:
- Ollama team for local LLM runtime
- Rust community for amazing ecosystem

---

## 📞 Contact

- **GitHub**: [@karthikeyanV2K](https://github.com/karthikeyanV2K)
- **Project**: [AFOT-Coretex](https://github.com/karthikeyanV2K/AFOT-Coretex)

---

## 🎉 Start Building!

```bash
# Get started in 3 steps:
cd Demo
cortex bind capabilities.yaml
cortex chat

You: Let's hack responsibly! 🚀
```

**CORTEX - Your AI-Powered Security Toolkit**

---

*Last Updated: January 2026*
*Version: 1.0.0-production*
